Select [MTPD],count([Critical Operations]) as Number_of_CO_in_that_period from [CM].[dbo].[Final_data] group by [MTPD];
Select Impacts, count(Consequences) as Number_of_Consequences from [CM].[dbo].[Final_data] group by Impacts;
Select [BAU_Locations],[Recovery_Locations] from [CM].[dbo].[Final_data] group by [Recovery_Locations],[BAU_Locations] ;
Select [MBCO],sum([Maxium_Data_Loss]) as sum_of_maximum_data_loss from [CM].[dbo].[Final_data] group by [MBCO] order by 1 asc;