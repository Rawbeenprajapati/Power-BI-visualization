CREATE TABLE Critical_Operation (
    Critical_Operation_id INT PRIMARY KEY IDENTITY(1,1),
    Critical_Operation NVARCHAR(255)
);
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Accounts Receivables');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Inventory Management');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Production Planning');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Quality Control');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Sales Forecasting');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Customer Relationship Management (CRM)');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Financial Reporting');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Budgeting and Forecasting');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Risk Management');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Regulatory Compliance');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Supply Chain Management');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Human Resources Management');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Marketing and Sales');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Information Technology Management');
INSERT INTO Critical_Operation (Critical_Operation) VALUES ('Strategic Planning');

//////////////////////////////////////////////////////////////////////////////////////////////////
CREATE TABLE Delegate_Managers (
    Delegate_Manager_id INT PRIMARY KEY IDENTITY(1,1),
    Delegate_Manager NVARCHAR(255)
);
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Emily Johnson');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Alex Rodriguez');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Sarah Smith');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('David Lee');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Michelle Williams');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Ryan Davis');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Amanda Brown');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Kevin Martinez');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Jessica Thompson');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Michael Clark');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Jennifer White');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Brian Taylor');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Samantha Garcia');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Daniel Wilson');
INSERT INTO Delegate_Managers (Delegate_Manager) VALUES ('Rachel Moore');
////////////////////////////////////////////////////////////////////////////////////////////
CREATE TABLE Department (
    Department_id INT PRIMARY KEY IDENTITY(1,1),
    Department NVARCHAR(255)
);
INSERT INTO Department (Department) VALUES ('Finance');
INSERT INTO Department (Department) VALUES ('Human Resources');
INSERT INTO Department (Department) VALUES ('Marketing');
INSERT INTO Department (Department) VALUES ('Sales');
INSERT INTO Department (Department) VALUES ('Information Technology');
INSERT INTO Department (Department) VALUES ('Operations');
INSERT INTO Department (Department) VALUES ('Customer Service');
INSERT INTO Department (Department) VALUES ('Research and Development');
INSERT INTO Department (Department) VALUES ('Legal');
INSERT INTO Department (Department) VALUES ('Administration');
INSERT INTO Department (Department) VALUES ('Supply Chain Management');
INSERT INTO Department (Department) VALUES ('Quality Assurance');
INSERT INTO Department (Department) VALUES ('Business Development');
INSERT INTO Department (Department) VALUES ('Public Relations');
INSERT INTO Department (Department) VALUES ('Facilities Management');
///////////////////////////////////////////////////////////////////////////////////////
CREATE TABLE Business_Team (
    Team_id INT PRIMARY KEY IDENTITY(1,1),
    Team nVARCHAR(255)
);
INSERT INTO Business_Team (Team) VALUES ('Strategy and Planning');
INSERT INTO Business_Team (Team) VALUES ('Business Development');
INSERT INTO Business_Team (Team) VALUES ('Marketing and Communications');
INSERT INTO Business_Team (Team) VALUES ('Sales and Account Management');
INSERT INTO Business_Team (Team) VALUES ('Product Management');
INSERT INTO Business_Team (Team) VALUES ('Customer Success');
INSERT INTO Business_Team (Team) VALUES ('Finance and Accounting');
INSERT INTO Business_Team (Team) VALUES ('Human Resources');
INSERT INTO Business_Team (Team) VALUES ('Operations and Logistics');
INSERT INTO Business_Team (Team) VALUES ('Information Technology');
INSERT INTO Business_Team (Team) VALUES ('Legal and Compliance');
INSERT INTO Business_Team (Team) VALUES ('Research and Development');
INSERT INTO Business_Team (Team) VALUES ('Quality Assurance');
INSERT INTO Business_Team (Team) VALUES ('Project Management');
INSERT INTO Business_Team (Team) VALUES ('Administration and Support');
//////////////////////////////////////////////////////////////////////////////////////////////////////
CREATE TABLE MTPD (
    MTPD_id INT PRIMARY KEY IDENTITY(1,1),
    MTPD nVARCHAR(255)
);
INSERT INTO MTPD (MTPD) VALUES ('Less than 6 hours');
INSERT INTO MTPD (MTPD) VALUES ('Less than 16 hours');
INSERT INTO MTPD (MTPD) VALUES ('Less than 24 hours');
INSERT INTO MTPD (MTPD) VALUES ('Less than 48 hours');
INSERT INTO MTPD (MTPD) VALUES ('Less than 7 days');
/////////////////////////////////////////////////////
CREATE TABLE Impacts (
    Impact_id INT PRIMARY KEY IDENTITY(1,1),
    Impact nVARCHAR(255)
);
INSERT INTO Impacts (Impact) VALUES ('Financial');
INSERT INTO Impacts (Impact) VALUES ('Operational');
INSERT INTO Impacts (Impact) VALUES ('Reputational');
INSERT INTO Impacts (Impact) VALUES ('Legal and Regulatory');
///////////////////////////////////////////////////////////////////////////
CREATE TABLE Consequences (
    Consequence_id INT PRIMARY KEY IDENTITY(1,1),
    Consequence nVARCHAR(255)
);
INSERT INTO Consequences (Consequence) VALUES ('Catastrophic');
INSERT INTO Consequences (Consequence) VALUES ('Major');
INSERT INTO Consequences (Consequence) VALUES ('Moderate');
/////////////////////////////////////////////////////////////////////////////
CREATE TABLE BAU_Locations (
    Location_id INT PRIMARY KEY IDENTITY(1,1),
    Location nVARCHAR(255)
);
INSERT INTO BAU_Locations (Location) VALUES ('123 Cherry Blossom Lane, Port Melbourne');
INSERT INTO BAU_Locations (Location) VALUES ('789 Mountain View Road, Blue Mountains');
INSERT INTO BAU_Locations (Location) VALUES ('222 Forest Hill Road, Adelaide');
INSERT INTO BAU_Locations (Location) VALUES ('444 Sunset Boulevard, Perth');
INSERT INTO BAU_Locations (Location) VALUES ('666 Beachfront Parade, Byron Bay');
INSERT INTO BAU_Locations (Location) VALUES ('888 Lakeshore Avenue, Melbourne');
INSERT INTO BAU_Locations (Location) VALUES ('111 Hilltop Road, Brisbane');
INSERT INTO BAU_Locations (Location) VALUES ('333 Ocean Road, Perth');
INSERT INTO BAU_Locations (Location) VALUES ('555 Mountain Drive, Adelaide');
INSERT INTO BAU_Locations (Location) VALUES ('777 Lakeside Drive, Melbourne');
INSERT INTO BAU_Locations (Location) VALUES ('456 Ocean View Drive, Bondi Beach');
INSERT INTO BAU_Locations (Location) VALUES ('101 Riverfront Avenue, Brisbane');
INSERT INTO BAU_Locations (Location) VALUES ('333 Lakeside Drive, Gold Coast');
INSERT INTO BAU_Locations (Location) VALUES ('555 Harbour View Terrace, Sydney');
INSERT INTO BAU_Locations (Location) VALUES ('777 Hillside Crescent, Hobart');
INSERT INTO BAU_Locations (Location) VALUES ('999 Pine Street, Sydney');
INSERT INTO BAU_Locations (Location) VALUES ('222 Valley View Drive, Gold Coast');
INSERT INTO BAU_Locations (Location) VALUES ('444 Riverfront Avenue, Sydney');
INSERT INTO BAU_Locations (Location) VALUES ('666 Sunset Boulevard, Hobart');
INSERT INTO BAU_Locations (Location) VALUES ('888 Forest Hill Road, Adelaide');
///////////////////////////////////////////////////////////////////////////////////////////////
CREATE TABLE Recovery_Locations (
    Location_id INT PRIMARY KEY IDENTITY(1,1),
    Location nVARCHAR(255)
);
INSERT INTO Recovery_Locations (Location) VALUES ('Remote Office');
INSERT INTO Recovery_Locations (Location) VALUES ('Cloud Storage');
INSERT INTO Recovery_Locations (Location) VALUES ('Cold Site');
INSERT INTO Recovery_Locations (Location) VALUES ('Shared Workspace');
INSERT INTO Recovery_Locations (Location) VALUES ('Colocation Facility');
INSERT INTO Recovery_Locations (Location) VALUES ('Backup Data Center');
INSERT INTO Recovery_Locations (Location) VALUES ('Virtual Recovery');
INSERT INTO Recovery_Locations (Location) VALUES ('Work from Home');
INSERT INTO Recovery_Locations (Location) VALUES ('Hot Site');
INSERT INTO Recovery_Locations (Location) VALUES ('Mobile Recovery Center');
///////////////////////////////////////////////////////////////////////////////
CREATE TABLE BAU_Suppliers (
    Supplier_id INT PRIMARY KEY IDENTITY(1,1),
    Supplier nVARCHAR(255)
);
INSERT INTO BAU_Suppliers (Supplier) VALUES ('Office Supplies Vendor');
INSERT INTO BAU_Suppliers (Supplier) VALUES ('Software Licensing Provider');
INSERT INTO BAU_Suppliers (Supplier) VALUES ('Janitorial Services Provider');
INSERT INTO BAU_Suppliers (Supplier) VALUES ('Telecommunications Provider');
INSERT INTO BAU_Suppliers (Supplier) VALUES ('Business Insurance Provider');
INSERT INTO BAU_Suppliers (Supplier) VALUES ('IT Hardware Supplier');
INSERT INTO BAU_Suppliers (Supplier) VALUES ('Office Furniture Supplier');
INSERT INTO BAU_Suppliers (Supplier) VALUES ('Printing Services Company');
INSERT INTO BAU_Suppliers (Supplier) VALUES ('Catering Services Company');
INSERT INTO BAU_Suppliers (Supplier) VALUES ('Legal Services Firm');
/////////////////////////////////////////////////////////////////////
CREATE TABLE IT_NonIT_Shared_Resources (
    Resource_id INT PRIMARY KEY IDENTITY(1,1),
    Resource nVARCHAR(255)
);
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('8x8');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('AXLA SDX');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Citrix HASNET drive');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Zoom');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Calendar');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Music app');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Eclipse (Dept of Education)');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('FTP Site Connections');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Ticketing system');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Financials');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Internal Servers');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Internet access across all sites');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Landline at head office only');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Microsoft Outlook');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Microsoft Teams');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Mimecast');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('MyFiles');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('NAB banking System');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('APRA');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('PCI PAL');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Payroll System');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Power to the facility');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('IDGH');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('THYD');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('RRSF');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('Sharepoint');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('SugarCRM');
INSERT INTO IT_NonIT_Shared_Resources (Resource) VALUES ('VPN Services');
/////////////////////////////////////////////////////////////////
CREATE TABLE IT_Applications (
    Application_id INT PRIMARY KEY IDENTITY(1,1),
    Application nVARCHAR(255)
);
INSERT INTO IT_Applications (Application) VALUES ('SAP A/P Module');
INSERT INTO IT_Applications (Application) VALUES ('Salesforce CRM');
INSERT INTO IT_Applications (Application) VALUES ('QuickBooks');
INSERT INTO IT_Applications (Application) VALUES ('Google Workspace');
INSERT INTO IT_Applications (Application) VALUES ('Zoom');
INSERT INTO IT_Applications (Application) VALUES ('Microsoft Teams');
INSERT INTO IT_Applications (Application) VALUES ('Confluence');
INSERT INTO IT_Applications (Application) VALUES ('Workday');
INSERT INTO IT_Applications (Application) VALUES ('Azure');
INSERT INTO IT_Applications (Application) VALUES ('HubSpot');
INSERT INTO IT_Applications (Application) VALUES ('Power BI');
INSERT INTO IT_Applications (Application) VALUES ('Shopify');
INSERT INTO IT_Applications (Application) VALUES ('SAP HCM Module');
INSERT INTO IT_Applications (Application) VALUES ('Microsoft Office Suite');
INSERT INTO IT_Applications (Application) VALUES ('Oracle ERP');
INSERT INTO IT_Applications (Application) VALUES ('Adobe Creative Cloud');
INSERT INTO IT_Applications (Application) VALUES ('Slack');
INSERT INTO IT_Applications (Application) VALUES ('Dropbox');
INSERT INTO IT_Applications (Application) VALUES ('Jira');
INSERT INTO IT_Applications (Application) VALUES ('ServiceNow');
INSERT INTO IT_Applications (Application) VALUES ('AWS');
INSERT INTO IT_Applications (Application) VALUES ('G Suite');
INSERT INTO IT_Applications (Application) VALUES ('Tableau');
INSERT INTO IT_Applications (Application) VALUES ('WordPress');
INSERT INTO IT_Applications (Application) VALUES ('Magento');

